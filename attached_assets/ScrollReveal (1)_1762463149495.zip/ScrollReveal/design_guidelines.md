# Design Guidelines: Interactive Scrolling Timeline Website

## Design Approach
**User-Specified Interactive Experience** - This is a highly interactive, scroll-driven single-page website featuring animated connecting elements and progressive content reveal.

## Core Design Principles
- **Vertical narrative flow**: Content reveals as user scrolls, creating a journey-like experience
- **Motion-rich interface**: Animations are central to the experience, not supplementary
- **Clean, focused layout**: Single-page design with no navigation needed
- **High contrast aesthetics**: White connecting lines and content boxes against background

## Layout System

**Spacing Strategy**
- Generous vertical spacing between image sections: py-32 to py-48 between major sections
- Content boxes positioned closely next to their associated images: gap-8 to gap-12
- Internal content box padding: p-6 to p-8
- Use Tailwind units: 4, 6, 8, 12, 16, 24, 32, 48 for consistent rhythm

**Section Structure**
- Top section: Earth image with title text positioned to the right or left
- Middle sections (5 total): Each image paired with a white content box (alternating left/right positioning recommended for visual interest)
- Bottom section: Large hero-style image without content box

## Typography
- **Title (next to Earth image)**: Large, bold display font (text-5xl to text-7xl)
- **Content box titles**: Medium weight headings (text-2xl to text-3xl)
- **Content box descriptions**: Regular body text (text-base to text-lg)
- **Font family**: Use modern sans-serif from Google Fonts (e.g., Inter, Poppins, or Space Grotesk)

## Component Library

### Image Components
- **Earth image**: Large focal image at top with accompanying title
- **5 middle images**: Medium-sized images that serve as waypoints along the connecting line
- **Final image**: Extra large, full-width or prominent closing image
- All images: Rounded corners (rounded-lg to rounded-2xl) for modern feel

### Content Boxes (5 required)
- **Structure**: White background containers with title + short paragraph
- **Visual treatment**: Subtle shadow (shadow-lg), rounded corners (rounded-xl)
- **Internal layout**: Clear hierarchy with title above description, generous internal spacing

### Connecting Line
- **Visual**: White vertical line connecting all images
- **Behavior**: Progressively reveals/draws as user scrolls down
- **Style**: Clean, 2-4px width, positioned along a curved or stepped path

## Animation Specifications

### Scroll-Triggered Animations
1. **Connecting line**: Gradually appears using SVG path animation or progressive height reveal
2. **Images moving along line**: Images translate along the connecting line trajectory as scroll progresses
3. **Content boxes popup**: Scale and fade in when scrolled into view (scale from 0.8 to 1.0, opacity 0 to 1)
4. **Final image**: Fade-in or scale-in animation when reaching bottom

### Hover Interactions
1. **Images**: Subtle scale (scale-105) or glow effect on hover
2. **Content boxes**: Highlight effect such as border glow, shadow intensification, or subtle lift (translateY)

## Images

### Required Images
1. **Earth image** (top section): Dramatic planet Earth photo from space, preferably showing continents and atmosphere
2. **5 waypoint images**: Varied thematic images that tell a story (suggest space/exploration theme, technology, or abstract visuals based on content)
3. **Final large image**: Impactful, high-resolution image serving as visual conclusion

All images should maintain consistent aspect ratio style (e.g., all 16:9 or mix of square and landscape) and high quality.

## Responsive Behavior
- **Desktop (lg+)**: Full interactive experience with side-by-side image/content box layouts
- **Tablet (md)**: Maintain animations but stack content boxes below images if needed
- **Mobile**: Single column with simplified animations, maintain scroll-triggered reveals

## Technical Animation Notes
- Use Intersection Observer API for scroll-triggered animations
- Track scroll position for progressive line drawing and image movement along path
- Smooth easing functions (ease-out for entrances, ease-in-out for movements)
- Consider using CSS transforms for performance (translate3d, scale)