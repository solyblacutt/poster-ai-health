import { useEffect, useState } from 'react';
import AnimatedImage from '@/components/AnimatedImage';
import ContentBox from '@/components/ContentBox';
import ConnectingLine from '@/components/ConnectingLine';

import earthImage from '@assets/generated_images/Earth_from_space_view_74c2a2be.png';
import astronautImage from '@assets/generated_images/Astronaut_floating_in_space_55e2d48b.png';
import spaceStationImage from '@assets/generated_images/Space_station_orbiting_Earth_f5485918.png';
import moonImage from '@assets/generated_images/Moon_surface_with_Earth_11bb3d50.png';
import marsImage from '@assets/generated_images/Mars_surface_landscape_2c42dbd5.png';
import nebulaImage from '@assets/generated_images/Colorful_space_nebula_c8e7ba24.png';

export default function Home() {
  const [titleVisible, setTitleVisible] = useState(false);

  useEffect(() => {
    setTimeout(() => setTitleVisible(true), 300);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-900 via-blue-800 to-blue-950 text-white overflow-x-hidden relative">
      <ConnectingLine />

      <div className="relative z-10">
        <section className="min-h-screen flex items-start justify-center px-4 md:px-8 pt-20">
          <div className="max-w-7xl w-full grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div className="flex justify-center md:justify-end">
              <AnimatedImage
                src={earthImage}
                alt="Earth"
                className="w-64 h-64 md:w-80 md:h-80"
                delay={100}
              />
            </div>
            <div
              className={`flex items-center transition-all duration-1000 ${
                titleVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-8'
              }`}
            >
              <ContentBox text="Some random contents" delay={200} />
            </div>
          </div>
        </section>

        <section className="min-h-[60vh] flex items-center justify-center px-4 md:px-8">
          <div className="max-w-7xl w-full grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div className="flex items-center md:order-1">
              <ContentBox text="Some random contents" delay={100} />
            </div>
            <div className="flex justify-center md:justify-start md:order-2">
              <AnimatedImage
                src={spaceStationImage}
                alt="Space Station"
                className="w-56 h-56 md:w-72 md:h-72"
                delay={200}
              />
            </div>
          </div>
        </section>

        <section className="min-h-[60vh] flex items-center justify-center px-4 md:px-8">
          <div className="max-w-7xl w-full grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div className="flex justify-center md:justify-end">
              <AnimatedImage
                src={moonImage}
                alt="Moon"
                className="w-64 h-64 md:w-80 md:h-80"
                delay={100}
              />
            </div>
            <div className="flex items-center">
              <ContentBox text="Some random contents" delay={200} />
            </div>
          </div>
        </section>

        <section className="min-h-[60vh] flex items-center justify-center px-4 md:px-8">
          <div className="max-w-7xl w-full grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div className="flex items-center justify-end md:order-1">
              <ContentBox text="Some random contents" delay={100} />
            </div>
            <div className="flex justify-center md:justify-start md:order-2">
              <AnimatedImage
                src={marsImage}
                alt="Mars"
                className="w-64 h-64 md:w-80 md:h-80"
                delay={200}
              />
            </div>
          </div>
        </section>

        <section className="min-h-[60vh] flex items-center justify-center px-4 md:px-8">
          <div className="max-w-7xl w-full grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div className="flex justify-center md:justify-end">
              <AnimatedImage
                src={nebulaImage}
                alt="Nebula"
                className="w-56 h-56 md:w-72 md:h-72"
                delay={100}
              />
            </div>
            <div className="flex items-center">
              <ContentBox text="Some random contents" delay={200} />
            </div>
          </div>
        </section>

        <section className="min-h-[60vh] flex items-center justify-center px-4 md:px-8 pb-20">
          <div className="max-w-7xl w-full grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div className="flex items-center md:order-1">
              <ContentBox text="Some random contents" delay={100} />
            </div>
            <div className="flex justify-center md:justify-start md:order-2">
              <AnimatedImage
                src={astronautImage}
                alt="Astronaut"
                className="w-64 h-64 md:w-80 md:h-80"
                delay={200}
              />
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
