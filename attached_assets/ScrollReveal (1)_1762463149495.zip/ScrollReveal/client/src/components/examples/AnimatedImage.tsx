import AnimatedImage from '../AnimatedImage';
import earthImage from '@assets/generated_images/Earth_from_space_view_74c2a2be.png';

export default function AnimatedImageExample() {
  return (
    <div className="bg-gray-900 p-8">
      <AnimatedImage
        src={earthImage}
        alt="Earth from space"
        className="w-64 h-64"
      />
    </div>
  );
}
