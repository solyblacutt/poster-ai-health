import ConnectingLine from '../ConnectingLine';

export default function ConnectingLineExample() {
  return (
    <div className="bg-gray-900 relative h-screen overflow-auto">
      <ConnectingLine />
      <div className="h-[200vh] flex items-center justify-center">
        <p className="text-white">Scroll to see the line animate</p>
      </div>
    </div>
  );
}
