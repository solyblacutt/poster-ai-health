import ContentBox from '../ContentBox';

export default function ContentBoxExample() {
  return (
    <div className="bg-gray-900 p-8">
      <ContentBox text="Some random contents" />
    </div>
  );
}
