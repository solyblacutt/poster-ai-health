import { useEffect, useState } from 'react';

export default function ConnectingLine() {
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const windowHeight = window.innerHeight;
      const documentHeight = document.documentElement.scrollHeight;
      const scrollTop = window.scrollY;
      const maxScroll = documentHeight - windowHeight;
      const progress = Math.min(1, Math.max(0, scrollTop / maxScroll));
      setScrollProgress(progress);
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll();

    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const curvedPath = `
    M 400 100
    Q 500 250, 400 400
    Q 300 550, 400 700
    Q 500 850, 400 1000
    Q 300 1150, 400 1300
    Q 500 1450, 400 1600
    Q 300 1750, 400 1900
    Q 500 2050, 400 2200
    Q 300 2350, 400 2500
  `;

  const pathElement = typeof document !== 'undefined' 
    ? document.createElementNS('http://www.w3.org/2000/svg', 'path')
    : null;
  
  if (pathElement) {
    pathElement.setAttribute('d', curvedPath);
  }
  
  const pathLength = pathElement?.getTotalLength() || 3000;
  const strokeDashoffset = pathLength * (1 - scrollProgress);

  return (
    <svg
      className="absolute left-0 top-0 w-full pointer-events-none z-0"
      viewBox="0 0 800 2600"
      preserveAspectRatio="xMidYMin slice"
      style={{ height: '100%', minHeight: '100vh' }}
    >
      <defs>
        <linearGradient id="lineGradient" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="white" stopOpacity="0.9" />
          <stop offset="100%" stopColor="white" stopOpacity="0.6" />
        </linearGradient>
      </defs>
      <path
        d={curvedPath}
        stroke="url(#lineGradient)"
        strokeWidth="2"
        fill="none"
        strokeDasharray={pathLength}
        strokeDashoffset={strokeDashoffset}
        className="transition-all duration-100 ease-linear"
        strokeLinecap="round"
      />
    </svg>
  );
}
