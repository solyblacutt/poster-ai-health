import { useEffect, useRef, useState } from 'react';

interface ContentBoxProps {
  text: string;
  delay?: number;
}

export default function ContentBox({ text, delay = 0 }: ContentBoxProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setTimeout(() => {
              setIsVisible(true);
            }, delay);
          }
        });
      },
      { threshold: 0.2 }
    );

    if (boxRef.current) {
      observer.observe(boxRef.current);
    }

    return () => {
      if (boxRef.current) {
        observer.unobserve(boxRef.current);
      }
    };
  }, [delay]);

  return (
    <div
      ref={boxRef}
      data-testid={`content-box-${text.toLowerCase().substring(0, 20).replace(/\s+/g, '-')}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className={`
        transition-all duration-700 ease-out
        ${isVisible ? 'opacity-100 scale-100 translate-y-0' : 'opacity-0 scale-95 translate-y-8'}
        ${isHovered ? 'scale-105 brightness-110' : ''}
      `}
      style={{
        transitionDelay: isVisible ? '0ms' : `${delay}ms`,
      }}
    >
      <p className="text-white text-lg font-medium">
        {text}
      </p>
    </div>
  );
}
