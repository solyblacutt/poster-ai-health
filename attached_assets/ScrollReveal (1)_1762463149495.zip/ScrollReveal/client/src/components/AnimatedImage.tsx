import { useEffect, useRef, useState } from 'react';

interface AnimatedImageProps {
  src: string;
  alt: string;
  className?: string;
  delay?: number;
}

export default function AnimatedImage({ 
  src, 
  alt, 
  className = '', 
  delay = 0
}: AnimatedImageProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const imageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setTimeout(() => {
              setIsVisible(true);
            }, delay);
          }
        });
      },
      { threshold: 0.2 }
    );

    if (imageRef.current) {
      observer.observe(imageRef.current);
    }

    return () => {
      if (imageRef.current) {
        observer.unobserve(imageRef.current);
      }
    };
  }, [delay]);

  return (
    <div
      ref={imageRef}
      data-testid={`animated-image-${alt.toLowerCase().replace(/\s+/g, '-')}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className={`
        transition-all duration-700 ease-out
        ${isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-90'}
        ${isHovered ? 'scale-105 brightness-110' : ''}
        ${className}
      `}
      style={{
        transitionDelay: isVisible ? '0ms' : `${delay}ms`,
      }}
    >
      <img
        src={src}
        alt={alt}
        className="w-full h-full object-cover rounded-full shadow-2xl"
      />
    </div>
  );
}
